## ----setup, include=FALSE-----------------------------------------------------
knitr::opts_chunk$set(echo = TRUE)
knitr::opts_knit$set(root.dir = "~/Documents")

## ----devtools, eval=F---------------------------------------------------------
# devtools::install_github("ucd-cepb/textnet")

## ----readpreprocessed, message=F, warning=F-----------------------------------
library(textNet)
#load sample tabular data, in which 
#each row is a single token
old_new_parsed <- textNet::old_new_parsed


## ----extract, results = 'hide'------------------------------------------------
#initialize empty list of extracts to populate
extracts <- vector(mode="list",length=length(old_new_parsed))
#populate each element of list with results of textnet_extract
#increasing "cl" to 4 for speed
#keeping four types of entities: organizations, 
#geopolitical entities, people, and water bodies
#keep_incomplete_edges is F by default; T keeps
#'edges' that are missing either a source node
#or a target node
for(m in 1:length(old_new_parsed)){
  extracts[[m]] <- textnet_extract(old_new_parsed[[m]],cl=4,
                   keep_entities = c('ORG','GPE','PERSON','WATER'), 
                   keep_incomplete_edges=T)
   }
   

## ----acronyms-----------------------------------------------------------------
#reading in sample text data
old_new_text <- textNet::old_new_text
#use find_acronyms feature to find and tabulate
#parenthetically defined acronyms within the text
old_acronyms <- find_acronyms(old_new_text[[1]])
new_acronyms <- find_acronyms(old_new_text[[2]])
   
print(head(old_acronyms))
   

## ----consolidate--------------------------------------------------------------
#the user can define a many-to-many matching
#scheme using a tofrom object as shown below
tofrom <- data.table::data.table(
  from = c(as.list(old_acronyms$acronym),
             list("Sub_basin",
                  "Sub_Basin",
                  "upper_and_lower_aquifers",
                  "Upper_and_lower_aquifers",
                  "Lower_and_upper_aquifers",
                  "lower_and_upper_aquifers")), 
  to = c(as.list(old_acronyms$name),
             list("Subbasin",
                  "Subbasin",
                  c("upper_aquifer","lower_aquifer"),
                  c("upper_aquifer","lower_aquifer"),
                  c("upper_aquifer","lower_aquifer"),
                  c("upper_aquifer","lower_aquifer"))))

#conduct many-to-many mapping and consolidate nodes that represent
#multiple ways of referring to a single entity 
#(e.g. acronyms. vs. full name)
old_extract_clean <- disambiguate(
  textnet_extract = extracts[[1]],
  from = tofrom$from, 
  to = tofrom$to,
  match_partial_entity = c(rep(F,nrow(old_acronyms)),T,T,F,F,F,F))

#same thing, now for the new network
tofrom <- data.table::data.table(
   from = c(as.list(new_acronyms$acronym),
             list("Sub_basin",
                  "Sub_Basin",
                  "upper_and_lower_aquifers",
                  "Upper_and_lower_aquifers",
                  "Lower_and_upper_aquifers",
                  "lower_and_upper_aquifers")), 
   to = c(as.list(new_acronyms$name),
             list("Subbasin",
                  "Subbasin",
                  c("upper_aquifer","lower_aquifer"),
                  c("upper_aquifer","lower_aquifer"),
                  c("upper_aquifer","lower_aquifer"),
                  c("upper_aquifer","lower_aquifer"))))
   
new_extract_clean <- disambiguate(
  textnet_extract = extracts[[2]], 
  from = tofrom$from, 
  to = tofrom$to,
  match_partial_entity = c(rep(F,nrow(new_acronyms)),T,T,F,F,F,F))


## ----export-------------------------------------------------------------------
#the second element in the object returned by export_to_network()
#is a tabular summary of network statistics
set.seed(50000)
old_extract_net <- export_to_network(old_extract_clean, "igraph", keep_isolates = F, 
                                        collapse_edges = F, self_loops = T)
set.seed(50000)
new_extract_net <- export_to_network(new_extract_clean, "igraph", keep_isolates = F, 
                                        collapse_edges = F, self_loops = T)
#table of old and new network statistics side by side
table <- t(format(rbind(old_extract_net[[2]], new_extract_net[[2]]), digits = 3, 
                     scientific = F))
colnames(table) <- c("old","new")
print(table)
   

## ----plot, message=F, warning=F-----------------------------------------------
library(ggraph)
#to plot the networks, the same export_to_network function can be used, 
#but a weighted version of the graph, such that all edges between 
#a given node pair are simplified into a single, weighted edge, 
#is better for plotting (i.e. collapse_edges = T)
set.seed(50000)
old_extract_plot <- export_to_network(old_extract_clean, "igraph", keep_isolates = F, 
                                         collapse_edges = T, self_loops = T)[[1]]
set.seed(50000)
new_extract_plot <- export_to_network(new_extract_clean, "igraph", keep_isolates = F, 
                                         collapse_edges = T, self_loops = T)[[1]]
#order of these layers matters
#use a package such as ggraph to plot igraph objects
set.seed(50000)
ggraph(old_extract_plot, layout = 'fr')+
      geom_edge_fan(aes(alpha = weight),
                    end_cap = circle(1,"mm"),
                    color = "#000000",
                    width = 0.3,
                    arrow = arrow(angle=15,length=unit(0.07,"inches"),ends = "last",
                                  type = "closed"))+
      #from Paul Tol's bright color scheme
      scale_color_manual(values = c("#4477AA","#228833","#CCBB44","#66CCEE"))+
      geom_node_point(aes(color = entity_type), size = 1,
                      alpha = 0.8)+
      labs(title= "Old Network")+
      theme_void()

#now the same thing, for the new network
#order of these layers matters
set.seed(50000)
ggraph(new_extract_plot, layout = 'fr')+
      geom_edge_fan(aes(alpha = weight),
                    end_cap = circle(1,"mm"),
                    color = "#000000",
                    width = 0.3,
                    arrow = arrow(angle=15,length=unit(0.07,"inches"),ends = "last",
                                  type = "closed"))+
      #from Paul Tol's bright color scheme
      scale_color_manual(values = c("#4477AA","#228833","#CCBB44","#66CCEE"))+
      geom_node_point(aes(color = entity_type), size = 1,
                      alpha = 0.8)+
      labs(title= "New Network")+
      theme_void()
   

## ----top----------------------------------------------------------------------
#summarizes the most common verbs (edges) and entities (nodes)
top_feats <- top_features(list(old_extract_net[[1]], new_extract_net[[1]]))
#the second element in the object returned from top_features is the edge summary
head(top_feats[[2]],10)

## ----step6b-------------------------------------------------------------------
#verb tense is one of the edge attributes returned by textnet_extract
#we use the multiplex graph (i.e. collapse_edges = F) to inspect them
table(igraph::E(old_extract_net[[1]])$head_verb_tense)

## ----composite----------------------------------------------------------------
#we generate a composite network with the function below
composite_net <- combine_networks(list(old_extract_net[[1]], new_extract_net[[1]]), 
                                     mode = "weighted")
set.seed(50000)
ggraph(composite_net, layout = 'fr')+
      geom_edge_fan(aes(alpha = weight),
                    end_cap = circle(1,"mm"),
                    color = "#000000",
                    width = 0.3,
                    arrow = arrow(angle=15,length=unit(0.07,"inches"),ends = "last",
                                  type = "closed"))+
      #from Paul Tol's bright color scheme
      scale_color_manual(values = c("#4477AA","#228833","#CCBB44","#66CCEE"))+
      geom_node_point(aes(color = entity_type), size = 1,
                      alpha = 0.8)+
      labs(title= "Composite Network")+
      theme_void()

## ----nodes, message=F, warning=F----------------------------------------------
library(network)
library(igraph)

top_feats <- top_features(list(old_extract_net[[1]], new_extract_net[[1]]))
#the first element in the object returned from top_features is the node summary
print(head(top_feats[[1]],10))

## ----step8b-------------------------------------------------------------------
#below is an example of how textNet data output 
#is compatible with node-level analysis, such as functions
#available through the sna package
composite_tbl <- igraph::as_data_frame(composite_net, what = "vertices")
composite_tbl <- composite_tbl[,c("name","num_graphs_in")]
    
#prepare data frame version of old network using "both"
#edge and node data, to add composite_tbl variables
old_tbl <- igraph::as_data_frame(old_extract_net[[1]], what = "both")
#in this example we want to incorporate the num_graphs_in variable 
#from composite_tbl into our analysis. We can use a join to do this
old_tbl$vertices <- dplyr::left_join(old_tbl$vertices, composite_tbl)
#ready to turn back into a network 
old_net <- network::network(x=old_tbl$edges[,1:2], directed = T,
                          hyper = F, loops = T, multiple = T, 
                          bipartiate = F, vertices = old_tbl$vertices,
                          matrix.type = "edgelist")
#we need a matrix version for some node statistics
set.seed(50000)
old_mat <- as.matrix(as.matrix(export_to_network(old_extract_clean, "igraph", 
                          keep_isolates = F, collapse_edges = T, self_loops = F)[[1]]))

#same thing, now for the new network    
#prepare data frame version of new network, to add composite_tbl variables
new_tbl <- igraph::as_data_frame(new_extract_net[[1]], what = "both")
#this adds the num_graphs_in variable from composite_tbl
new_tbl$vertices <- dplyr::left_join(new_tbl$vertices, composite_tbl)
#turn back into a network
new_net <- network::network(x=new_tbl$edges[,1:2], directed = T,
                          hyper = F, loops = T, multiple = T, 
                          bipartiate = F, vertices = new_tbl$vertices,
                          matrix.type = "edgelist")
#we need a matrix version for some node statistics
set.seed(50000)
new_mat <- as.matrix(as.matrix(export_to_network(new_extract_clean, "igraph", 
                          keep_isolates = F, collapse_edges = T, self_loops = F)[[1]]))

## ----step8b2------------------------------------------------------------------
#we can now calculate various node-level statistics on the network
paths2 <- diag(old_mat %*% old_mat)
recip <- 2*paths2 / sna::degree(old_net)
totalCC <- as.vector(unname(DirectedClustering::ClustF(old_mat, 
            type = "directed", isolates="zero")$totalCC))
closens <- sna::closeness(old_net, gmode = "graph", cmode="suminvundir")
between <- sna::betweenness(old_net,gmode = "graph",cmode="undirected")
deg <- sna::degree(old_net, gmode = "graph", cmode = "undirected")
old_node_df <- dplyr::tibble(name = network::get.vertex.attribute(old_net,
            "vertex.names"), 
            closens, 
            between, 
            deg,
            recip,
            totalCC,
            entity_type = network::get.vertex.attribute(old_net,"entity_type"),
            num_graphs_in = network::get.vertex.attribute(old_net, "num_graphs_in"))
    
#same thing for the new network
paths2 <- diag(new_mat %*% new_mat)
recip <- 2*paths2 / sna::degree(new_net)
totalCC <- as.vector(unname(DirectedClustering::ClustF(new_mat, 
                 type = "directed", isolates="zero")$totalCC))
closens <- sna::closeness(new_net, gmode = "graph", cmode="suminvundir")
between <- sna::betweenness(new_net,gmode = "graph",cmode="undirected")
deg <- sna::degree(new_net, gmode = "graph", cmode = "undirected")
new_node_df <- dplyr::tibble(name = network::get.vertex.attribute(new_net,
            "vertex.names"), 
            closens, 
            between, 
            deg,
            recip,
            totalCC,
            entity_type = network::get.vertex.attribute(new_net,"entity_type"),
            num_graphs_in = network::get.vertex.attribute(new_net, "num_graphs_in"))
    
summary(old_node_df)
summary(new_node_df)
    

## ----step8b3------------------------------------------------------------------
#summary of which entity types are in each plan
old_node_df$plan_version <- "old"
new_node_df$plan_version <- "new"
combineddf <- rbind(old_node_df, new_node_df)
with(combineddf,table(plan_version,num_graphs_in))
    

## ----step8b4, warning=F, message=F--------------------------------------------
library(gridExtra)
library(ggplot2)
#summary of differences between the two plans
#on a selection of network statistics
b1 <- ggplot(old_node_df, aes(x = entity_type, y = deg)) + geom_boxplot() + theme_bw() + labs(title="Old Network")
b2 <- ggplot(new_node_df, aes(x = entity_type, y = deg)) + geom_boxplot() + theme_bw() + labs(title="New Network")
b3 <- ggplot(old_node_df, aes(x = entity_type, y = log(between+0.01))) + 
          geom_boxplot() + theme_bw() + labs(title="Old Network")
b4 <- ggplot(new_node_df, aes(x = entity_type, y = log(between+0.01))) + 
      geom_boxplot() + theme_bw() + labs(title="New Network")

grid.arrange(b1, b2, b3, b4, ncol=2)

## ----pdf_clean, eval = F------------------------------------------------------
# library(textNet)
# library(stringr)
# #download sample pdf data from state website
# #this is the same as old.pdf and new.pdf
# #that are included in the package
# URL <- "https://sgma.water.ca.gov/portal/service/gspdocument/download/2840"
# download.file(URL, destfile = "vignettes/old.pdf", method="curl")
# 
# URL <- "https://sgma.water.ca.gov/portal/service/gspdocument/download/9625"
# download.file(URL, destfile = "vignettes/new.pdf", method="curl")
# 
# pdfs <- c("vignettes/old.pdf",
#           "vignettes/new.pdf")
# 
# #this is the equivalent of the textNet::old_new_text sample data
# #that travels with the package
# old_new_text <- textNet::pdf_clean(pdfs, ocr=F, maxchar=10000,
#                      export_paths=NULL, return_to_memory=T, suppressWarn = F,
#                      auto_headfoot_remove = T)
# names(old_new_text) <- c("old","new")

## ----parse, eval = F----------------------------------------------------------
# library(findpython)
# #find the version of python that has the required NLP modules
# ret_path <- find_python_cmd(required_modules = c('spacy', 'en_core_web_lg'))
# 
# #example of how to define a custom list for a user-defined entity type
# water_bodies <- c("surface water", "Surface water", "groundwater", "Groundwater",
#                   "San Joaquin River", "Cottonwood Creek", "Chowchilla Canal Bypass",
#                   "Friant Dam", "Sack Dam", "Friant Canal", "Chowchilla Bypass",
#                   "Fresno River", "Sacramento River", "Merced River","Chowchilla River",
#                   "Bass Lake", "Crane Valley Dam", "Willow Creek", "Millerton Lake",
#                   "Mammoth Pool", "Dam 6 Lake", "Delta","Tulare Lake",
#                   "Madera-Chowchilla canal", "lower aquifer", "upper aquifer",
#                   "upper and lower aquifers", "lower and upper aquifers",
#                   "Lower aquifer", "Upper aquifer", "Upper and lower aquifers",
#                   "Lower and upper aquifers")
# 
# if(!requireNamespace("spacyr", quietly = T)){
#     stop("Package 'spacyr' must be installed to use this function.",
#          call.=F)
# }
# #this is the equivalent of the textNet::old_new_parsed sample data
# #that travels with the package
# #it is a thin wrapper for spacyr::spacy_parse
# old_new_parsed <- textNet::parse_text(ret_path,
#                           keep_hyph_together = F,
#                           phrases_to_concatenate = water_bodies,
#                           concatenator = "_",
#                           text_list = old_new_text,
#                                  parsed_filenames=c("old_parsed","new_parsed"),
#                                  overwrite = T,
#                           custom_entities = list(WATER = water_bodies))
# 

